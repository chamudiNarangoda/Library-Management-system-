<?php
$servername="localhost";
$username="root";
$password="";
$link=mysqli_connect($servername,$username,$password);
if($link==false){
	die("Error to connect ".mysqli_connect_error());
}
	

?>