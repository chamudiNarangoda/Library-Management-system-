<?php
include 'connection.php';
session_start();
error_reporting(0);
?><div class="container"> <?php	
	if($link->connect_error){
	die('database connection failed ');

}
$sql3="CREATE TABLE if not exists book_details (
		  B_id int(100) NOT NULL,
		  Book_name varchar(100) NOT NULL,
		  Author varchar(100) NOT NULL,
		  Publication_year varchar(100) NOT NULL,
		  Language varchar(100) NOT NULL,
		  NO_of_copies varchar(100) NOT NULL,
		  Catagory varchar(100) NOT NULL
		)";
mysqli_select_db($link,"LMS");
if(mysqli_query($link,$sql3)){	

$Bname=$_POST['Bname'];
$Author=$_POST['Author'];
$Pyear=$_POST['Pyear'];
$Language=$_POST['Language'];
$Copies=$_POST['Copies'];
$Catagory=$_POST['Catagory'];



$insert ="INSERT into book_details(Book_name,Author,Publication_year,Language,NO_of_copies,Catagory) values('$Bname','$Author','$Pyear','$Language','$Copies','$Catagory')";

	if(mysqli_query($link,$insert)){
	echo "Successfully insert data <br><br />";
}else{
	echo "Error Data Insertion...".mysqli_error($link);
}
}	
mysqli_close($link);

?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Book</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="style3.css">
    <link rel="stylesheet" type="text/css" href="style2.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
 <div class="sidebar close">

<br></br>
    <ul class="nav-links">
    	<li>
        <a href="Dashbord.php">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">DASHBORD</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="Dashbord.php">DASHBORD</a></li>			<!-- add student link-->
        </ul>
      </li>

      <li>
        <a href="addBook.php">
          <i class='bx bx-plus-circle' ></i>
          <span class="link_name">ADD BOOK</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="addBook.php">ADD BOOK</a></li>			<!-- add student link-->
        </ul>
      </li>
      
      <li>
        <a href="addMember.php">
          <i class='bx bx-pie-chart-alt-2' ></i>
          <span class="link_name">ADD MEMBER</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="addMember.php">ADD MEMBER</a></li>			<!-- add student link-->
        </ul>
      </li>
      <li>
        <a href="memberDetails.php">
          <i class='bx bx-line-chart' ></i>
          <span class="link_name">MEMBER DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="memberDetails.php">MEMBER DETAILS</a></li>				<!--Attendence link-->
        </ul>
      </li>
      
      <li>
        <a href="bookDetails.php">
          <i class='bx bx-detail' ></i>
          <span class="link_name">BOOK DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="bookDetails.php">BOOK DETAILS</a></li>				<!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="ishuBook.php">
          <i class='bx bx-briefcase-alt-2' ></i>
          <span class="link_name">ISSHUE BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="ishuBook.php">ISSHUE BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="return.php">
          <i class='bx bx-compass' ></i>
          <span class="link_name">RETURN BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="return.php">RETURN BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
</ul>
  </div>
</body>
</html>