<?php
include 'connection.php';

session_start();

error_reporting(0);

mysqli_select_db($link,"LMS");

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$password = ($_POST['password']);

	$sql = "SELECT * FROM users WHERE username='$username' && Password='$password'";
	$result = mysqli_query($link,$sql);

	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $row['username'];
		header("Location: Dashbord.php");
	} else {
		echo "<script>alert('Woops! username or Password is Wrong.')</script>";
	}
}
?>
<html>
<head>
	<meta http-equiv="Cache-control" content="no-cache">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Login</title></head>
<body>

	<div class="container">
	<form method="POST" class="login-email">
		<p class="login-text" style="font-size: 2rem; font-weight: 200;">Library Manegement System</p><br><br>
		<p class="login-text" style="font-size: 2rem; font-weight: 200;">LOGIN</p>
		<div class="input-group">
			<input type="text" name="username" placeholder="User Name" required><br>
		</div>
		<div class="input-group">
			<input type="password" placeholder="Password" name="password" required>
		</div>
		<div class="input-group">
				<div class="center">
		<button name="submit" class="btn">Login</button>
	</div>
</div>
		<p class="login-register-text">Don't have an account? <a href="register.php">Register Now</a>.</p>
	</form>
</div>
</body>
</html>