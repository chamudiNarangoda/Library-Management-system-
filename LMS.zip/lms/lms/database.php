<?php
include 'connection.php';
session_start();
error_reporting(0);
?>
<div class="container"><?php
	$sql1="CREATE DATABASE if not exists LMS";
	
	if(mysqli_query($link,$sql1)){

	echo "Database has been created <br><br />";
	$sql2="CREATE TABLE if not exists users(
		id INT PRIMARY KEY AUTO_INCREMENT,
		username VARCHAR(100) NOT NULL,
		Email VARCHAR(100) NOT NULL,		
		Password VARCHAR(100) NOT NULL
	)";


	mysqli_select_db($link,"LMS");

	if(mysqli_query($link,$sql2)){
		echo "Table has been created<br /><br />";

$User=$_POST['username'];
$email=$_POST['email'];
$Pass=$_POST['password'];

	$insert ="Insert into users(username,Email,Password) Values('$User','$email','$Pass')";
	if(mysqli_query($link,$insert)){
	echo "Successfully created user account <br><br />";
	?><div class="input-group">
	<br><br>
		<p class="login-register-text">Now you Have an account? <a href="Login.php">Login Here</a></p>
	</div>
	<?php
}else{
	echo "Error Data Insertion...".mysqli_error($link);
}
				
}else{
		echo "Error...".mysqli_error($link);
	}
}else{
	echo "Error...".mysqli_error($link);
}
?>
<!DOCTYPE html>
<html>
<head>
	 <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="style3.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Create user Account</title>
</head>
<body>
<div class="sidebar close">

<br></br>
    <ul class="nav-links">
      <li>
        <a href="Login.php">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">Login</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="Login.php">Login</a></li>			<!-- add student link-->
        </ul>
      </li>
      

  </body>
  </html>