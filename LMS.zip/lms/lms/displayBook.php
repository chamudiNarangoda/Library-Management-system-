  <?php
  include 'connection.php';
session_start();
error_reporting(0);
mysqli_select_db($link,"lms");

  $sql="SELECT * FROM issue_book";
  $result = mysqli_query($link,$sql);
  ?>
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" type="text/css" href="style.css">

    <link rel="stylesheet" href="style3.css">
    <link rel="stylesheet" href="style2.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>issued book list</title>
  </head>
  <body>
  
  </body>
    <div class="container">
  </html><h3><center>Issued Books</center></h3><br><br>

  <table border="1">
    <tr>
      <td>Member ID</td>
      <td>Member Name</td>
      <td>Book ID</td>
      <td>Book Name</td>
      <td>Issued date</td>
      
    </tr>

    <?php while($row=mysqli_fetch_assoc($result)) { ?>
    <tr>
      <td><?php echo $row['Member_ID']; ?></td>
      <td><?php echo $row['Member_name']; ?></td>
      <td><?php echo $row['B_Id']; ?></td>
      <td><?php echo $row['B_Name']; ?></td>
      <td><?php echo $row['Issued_date']; ?></td>
      
    </tr>
  <?php }
?>
  <div class="sidebar close">

<br></br>
    <ul class="nav-links">
      <li>
        <a href="Dashbord.php">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">DASHBORD</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="Dashbord.php">DASHBORD</a></li>      <!-- add student link-->
        </ul>
      </li>

      <li>
        <a href="addBook.php">
          <i class='bx bx-plus-circle' ></i>
          <span class="link_name">ADD BOOK</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="addBook.php">ADD BOOK</a></li>     <!-- add student link-->
        </ul>
      </li>
      
      <li>
        <a href="addMember.php">
          <i class='bx bx-pie-chart-alt-2' ></i>
          <span class="link_name">ADD MEMBER</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="addMember.php">ADD MEMBER</a></li>     <!-- add student link-->
        </ul>
      </li>
      <li>
        <a href="memberDetails.php">
          <i class='bx bx-line-chart' ></i>
          <span class="link_name">MEMBER DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="memberDetails.php">MEMBER DETAILS</a></li>       <!--Attendence link-->
        </ul>
      </li>
      
      <li>
        <a href="bookDetails.php">
          <i class='bx bx-detail' ></i>
          <span class="link_name">BOOK DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="bookDetails.php">BOOK DETAILS</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="ishuBook.php">
          <i class='bx bx-briefcase-alt-2' ></i>
          <span class="link_name">ISSHUE BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="ishuBook.php">ISSHUE BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="return.php">
          <i class='bx bx-compass' ></i>
          <span class="link_name">RETURN BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="return.php">RETURN BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
</ul>
  </div>
</table>
</div>
</body>
</html>