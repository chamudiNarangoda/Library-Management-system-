
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

    <link rel="stylesheet" href="style3.css">
    <link rel="stylesheet" href="style2.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>issue Book</title>
</head>
<body>
	<div class="container">
		<form action="issue.php" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">ISSHU BOOK</p>
			<div class="input-group">
				<input type="text" placeholder="Member ID" name="M_ID"  required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Member name" name="M_name"  required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Book Name" name="B_Name"  required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Book Id" name="B_ID"  required>
			</div>
			<div class="input-group">
				<input type="date" placeholder="issued date " name="issued_date"  required>
			</div>
			<div class="input-group">
				<center><button name="submit" class="btn">ISSUE</button></center>
			</div>
		</form>
		
	</div>
	<div class="sidebar close">

<br></br>
    <ul class="nav-links">
    	<li>
        <a href="Dashbord.php">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">DASHBORD</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="Dashbord.php">DASHBORD</a></li>			<!-- add student link-->
        </ul>
      </li>

      <li>
        <a href="addBook.php">
          <i class='bx bx-plus-circle' ></i>
          <span class="link_name">ADD BOOK</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="addBook.php">ADD BOOK</a></li>			<!-- add student link-->
        </ul>
      </li>
      
      <li>
        <a href="addMember.php">
          <i class='bx bx-pie-chart-alt-2' ></i>
          <span class="link_name">ADD MEMBER</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="addMember.php">ADD MEMBER</a></li>			<!-- add student link-->
        </ul>
      </li>
      <li>
        <a href="memberDetails.php">
          <i class='bx bx-line-chart' ></i>
          <span class="link_name">MEMBER DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="memberDetails.php">MEMBER DETAILS</a></li>				<!--Attendence link-->
        </ul>
      </li>
      
      <li>
        <a href="bookDetails.php">
          <i class='bx bx-detail' ></i>
          <span class="link_name">BOOK DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="bookDetails.php">BOOK DETAILS</a></li>				<!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="ishuBook.php">
          <i class='bx bx-briefcase-alt-2' ></i>
          <span class="link_name">ISSHUE BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="ishuBook.php">ISSHUE BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="return.php">
          <i class='bx bx-compass' ></i>
          <span class="link_name">RETURN BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="return.php">RETURN BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
</ul>
  </div>
</body>
</html>