<?php
include 'connection.php';
session_start();
error_reporting(0);

mysqli_select_db($link,"lms");
$sql4="CREATE TABLE if not exists issue_book (
      Member_ID int(100) NOT NULL,
      Member_name varchar(100) NOT NULL,
      B_Id int(100) NOT NULL,
      B_Name varchar(100) NOT NULL,
      Issued_date date NOT NULL
    )";
if(mysqli_query($link,$sql4)){



$M_ID=$_POST['M_ID'];
$M_name=$_POST['M_name'];
$B_Name=$_POST['B_Name'];
$B_ID=$_POST['B_ID'];
$issued_date=$_POST['issued_date'];

mysqli_select_db($link,"LMS");

$insert ="INSERT into issue_book(Member_ID,Member_name,B_Name,B_ID,issued_date) values('$M_ID','$M_name','$B_Name','$B_ID','$issued_date')";
}
?>
<div class="container"><?php
	if(mysqli_query($link,$insert)){
	echo "Successfully insert data <br><br />";
}else{
	echo "Error Data Insertion...".mysqli_error($link);
}
		
mysqli_close($link);
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="style3.css">
    <link rel="stylesheet" href="style2.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
</head>
<body>
<form class="login-email" method="POST" action="displayBook.php">
  <lable>Click here to check issued book list</lable><br><br>
  <div class="input-group">
  <button name="submit" class="btn">Check</button>
</div>
</form>
</div>
	</table>
 <div class="sidebar close">

<br></br>
    <ul class="nav-links">
    	<li>
        <a href="Dashbord.php">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">DASHBORD</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="Dashbord.php">DASHBORD</a></li>			<!-- add student link-->
        </ul>
      </li>

      <li>
        <a href="addBook.php">
          <i class='bx bx-plus-circle' ></i>
          <span class="link_name">ADD BOOK</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="addBook.php">ADD BOOK</a></li>			<!-- add student link-->
        </ul>
      </li>
      
      <li>
        <a href="addMember.php">
          <i class='bx bx-pie-chart-alt-2' ></i>
          <span class="link_name">ADD MEMBER</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="addMember.php">ADD MEMBER</a></li>			<!-- add student link-->
        </ul>
      </li>
      <li>
        <a href="memberDetails.php">
          <i class='bx bx-line-chart' ></i>
          <span class="link_name">MEMBER DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="memberDetails.php">MEMBER DETAILS</a></li>				<!--Attendence link-->
        </ul>
      </li>
      
      <li>
        <a href="bookDetails.php">
          <i class='bx bx-detail' ></i>
          <span class="link_name">BOOK DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="bookDetails.php">BOOK DETAILS</a></li>				<!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="ishuBook.php">
          <i class='bx bx-briefcase-alt-2' ></i>
          <span class="link_name">ISSHUE BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="ishuBook.php">ISSHUE BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="return.php">
          <i class='bx bx-compass' ></i>
          <span class="link_name">RETURN BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="return.php">RETURN BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
</ul>
  </div>
</body>
</html>
