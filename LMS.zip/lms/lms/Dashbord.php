<?php
error_reporting(0);
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="Cache-control" content="no-cache">
    <title> Dashbord</title>
    <link rel="stylesheet" href="style3.css">
    <link rel="stylesheet" href="style2.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <style>
       body{
        background-image: linear-gradient(rgba(0,0,0,.5), rgba(0,0,0,.5)), url(background3.jpg);
       }
     </style>
   </head>
<body>

 <div class="sidebar close">

<br></br>
    <ul class="nav-links">
    	<li>
        <a href="Dashbord.php">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">DASHBORD</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="Dashbord.php">DASHBORD</a></li>			<!-- add student link-->
        </ul>
      </li>

      <li>
        <a href="addBook.php">
          <i class='bx bx-plus-circle' ></i>
          <span class="link_name">ADD BOOK</span>
        </a>
       <ul class="sub-menu blank">
          <li><a class="link_name" href="addBook.php">ADD BOOK</a></li>			<!-- add student link-->
        </ul>
      </li>
      
      <li>
        <a href="addMember.php">
          <i class='bx bx-pie-chart-alt-2' ></i>
          <span class="link_name">ADD MEMBER</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="addMember.php">ADD MEMBER</a></li>			<!-- add student link-->
        </ul>
      </li>
      <li>
        <a href="memberDetails.php">
          <i class='bx bx-line-chart' ></i>
          <span class="link_name">MEMBER DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="memberDetails.php">MEMBER DETAILS</a></li>				<!--Attendence link-->
        </ul>
      </li>
      
      <li>
        <a href="bookDetails.php">
          <i class='bx bx-detail' ></i>
          <span class="link_name">BOOK DETAILS</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="bookDetails.php">BOOK DETAILS</a></li>				<!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="ishuBook.php">
          <i class='bx bx-briefcase-alt-2' ></i>
          <span class="link_name">ISSHUE BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="ishuBook.php">ISSHUE BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
      <li>
        <a href="return.php">
          <i class='bx bx-compass' ></i>
          <span class="link_name">RETURN BOOK</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="return.php">RETURN BOOK</a></li>       <!--//cehck status page link-->
        </ul>
      </li>
</ul>
  </div>
  <div class="button">

  <button class="btn btn3"><a class="link_name3" href="addMember.php">ADD MEMBER</a></button>
  <button class="btn btn5"><a class="link_name5" href="ishuBook.php">ISSHUE BOOK</a> </button>
  <button class="btn btn2"><a class="link_name2" href="memberDetails.php">MEMBER DETAILS</a> </button><br>
    <button class="btn btn1"><a class="link_name1" href="addBook.php">ADD BOOK</a></button>
    <button class="btn btn4"><a class="link_name4" href="bookDetails.php" >BOOK DETAILS</a></button>
  <button class="btn btn6"><a class="link_name6" href="return.php">RETURN BOOK</a> </button>

</div>
  <script src="script.js"></script>

</body>
</html>